#Google Calendar App Sample

NodeJs server setup
* Install npm and node
* Run `npm install` to install node_modules
* Create google service account and download json file, Then copy it into `src/config` folder
* Now write json file name in `src/config/google.config.js`

React client setup
* Run `cd client`
* Run `npm install`

Start Application
* Run `npm start` to start server
* Open browser with url `http://localhost:3000`